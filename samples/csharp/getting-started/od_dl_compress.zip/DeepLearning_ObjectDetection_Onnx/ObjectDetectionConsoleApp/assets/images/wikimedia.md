Wikimedia links of images. If you go to below links the images and their licenses are available in wikimedia commons.

https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/-EXPO_BERGER_10_10_2004_048_%288054969288%29.jpg/640px--EXPO_BERGER_10_10_2004_048_%288054969288%29.jpg
https://commons.wikimedia.org/wiki/File:GATOS.jpg
https://commons.wikimedia.org/wiki/File:Dining_Room_556.jpg
https://commons.wikimedia.org/wiki/File:Fiat126_Pop2000_Cabrio.jpg